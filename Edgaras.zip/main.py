#!/usr/bin/env python3

from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import uvicorn
import sqlite3


app = FastAPI(title="A car selling website")
app.mount("/static", StaticFiles(directory="static"), name="static")
conn = sqlite3.connect("./cars.db")
templates = Jinja2Templates(directory="./templates")


if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=5000, reload=True)


@app.get("/")
async def get_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/browse")
async def browse_cars(request: Request):
    c = conn.cursor()
    c.execute("SELECT * FROM cars")
    cars = c.fetchall()
    return templates.TemplateResponse("browse.html", {"request": request, "cars": cars})


@app.get("/thank-you")
async def thank_you(request: Request):
    return templates.TemplateResponse("thankyou.html", {"request": request})


@app.get("/sell")
async def sell_car(request: Request):
    return templates.TemplateResponse("sell.html", {"request": request})


@app.post("/sell/post")
async def post_car(request: Request, seller: str = Form(...), model: str = Form(...), make: str = Form(...), price: int = Form(...)):
    c = conn.cursor()
    c.execute(
        f"INSERT INTO cars VALUES ('{model}', '{make}', '{int(price)}', '{seller}')")
    conn.commit()
    return templates.TemplateResponse("thankyou.html", {"request": request})


@app.get("/reviews")
async def get_reviews(request: Request):
    c = conn.cursor()
    c.execute("SELECT * FROM reviews")
    reviews = c.fetchall()
    return templates.TemplateResponse("reviews.html", {"request": request, "reviews": reviews})


@app.get("/review")
async def create_review(request: Request):
    return templates.TemplateResponse("review.html", {"request": request})


@app.post("/review/post")
async def post_review(request: Request, name: str = Form(...), stars: int = Form(...), content: str = Form(...)):
    c = conn.cursor()
    c.execute(
        f"INSERT INTO reviews VALUES ('{name}', '{stars}', '{content}')")
    conn.commit()
    return templates.TemplateResponse("thankyou.html", {"request": request})


@app.get("/contact-seller/{name}")
async def contact_seller(request: Request, name: str):
    return templates.TemplateResponse("contactseller.html", {"request": request, "name": name})
